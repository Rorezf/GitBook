package io.qameta.allure.metric;

/**
 * @author charlie (Dmitry Baev).
 */
public interface MetricLine {

    String asString();

}
