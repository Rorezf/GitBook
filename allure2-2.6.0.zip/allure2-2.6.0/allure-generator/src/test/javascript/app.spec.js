import App from 'app';

describe('app', function() {
    it('should instantiate application', function() {
        expect(App).toBeDefined();
    });
});
