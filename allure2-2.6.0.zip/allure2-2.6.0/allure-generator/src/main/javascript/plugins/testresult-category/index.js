import CategoryView from './CategoryView';

allure.api.addTestResultBlock(CategoryView, {position: 'tag'});
