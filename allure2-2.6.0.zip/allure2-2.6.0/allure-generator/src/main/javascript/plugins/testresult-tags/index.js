import TagsView from './TagsView';

allure.api.addTestResultBlock(TagsView, {position: 'tag'});
