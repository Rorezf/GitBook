import {Collection} from 'backbone';

export default class GraphCollection extends Collection {
    url = 'widgets/status-chart.json';
}
