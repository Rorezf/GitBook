import EnvironmentWidget from './EnvironmentWidget';

allure.api.addWidget('widgets', 'environment', EnvironmentWidget);
