import LaunchesWidgetView from './LaunchesWidgetView';

allure.api.addWidget('widgets', 'launches', LaunchesWidgetView);