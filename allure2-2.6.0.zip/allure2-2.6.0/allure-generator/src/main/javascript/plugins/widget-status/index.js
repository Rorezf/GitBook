import StatusChartView from './StatusWidgetView';

allure.api.addWidget('graph', 'status-chart', StatusChartView);