import ParametersView from './ParametersView';

allure.api.addTestResultBlock(ParametersView, {position: 'before'});
