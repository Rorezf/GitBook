import ExecutorsWidgetView from './ExecutorsWidgetView';

allure.api.addWidget('widgets', 'executors', ExecutorsWidgetView);