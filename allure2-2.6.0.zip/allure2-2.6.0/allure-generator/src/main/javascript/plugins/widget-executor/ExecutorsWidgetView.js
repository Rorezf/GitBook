import {View} from 'backbone.marionette';
import template from './ExecutorsWidgetView.hbs';

class ExecutorsWidgetView extends View {
    template = template;
}

export default ExecutorsWidgetView;