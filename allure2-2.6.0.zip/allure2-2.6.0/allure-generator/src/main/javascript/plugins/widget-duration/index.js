import DurationChartView from './DurationWidgetView';

allure.api.addWidget('graph', 'duration', DurationChartView);