import SeverityView from './SeverityView';

allure.api.addTestResultBlock(SeverityView, {position: 'tag'});