import RetriesView from './RetriesView';

allure.api.addTestResultTab('retries', 'testResult.retries.name', RetriesView);